// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.ubufox@ubuntu.com.description", "chrome://ubufox/locale/ubufox.properties");
